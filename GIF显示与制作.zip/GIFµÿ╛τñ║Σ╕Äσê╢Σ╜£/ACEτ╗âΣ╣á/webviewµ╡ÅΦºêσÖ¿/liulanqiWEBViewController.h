//
//  liulanqiWEBViewController.h
//  GIF显示与制作
//
//  Created by admin on 16/9/6.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ViewController.h"

@interface liulanqiWEBViewController : ViewController
@property (weak, nonatomic) IBOutlet UIView *webSZ;

@end
