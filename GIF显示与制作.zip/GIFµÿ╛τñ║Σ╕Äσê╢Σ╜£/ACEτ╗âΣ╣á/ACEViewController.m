//
//  ACEViewController.m
//  GIF显示与制作
//
//  Created by admin on 16/9/5.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ACEViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/Photos.h>
#import "ACECollectionViewCell.h"
@interface ACEViewController ()<UIImagePickerControllerDelegate, UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UIWebViewDelegate>
{

    NSMutableArray * imageArray;

}
@end

@implementation ACEViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    imageArray=[[NSMutableArray alloc] initWithCapacity:0];
//     [self getImageFromIpc];
    
    [self getOriginalImages];
    
    /////////////////////////////////////////
//    //    1.设置请求路径
//    NSString *urlStr=[NSString stringWithFormat:@"https://www.hao123.com"];
//    NSURL *url=[NSURL URLWithString:urlStr];
//    
//    //    2.创建请求对象
//    NSURLRequest *request=[NSURLRequest requestWithURL:url];
//    
//    //    3.发送请求
//    //3.1发送同步请求，在主线程执行
//    //    NSData *data=[NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
//    //（一直在等待服务器返回数据，这行代码会卡住，如果服务器没有返回数据，那么在主线程UI会卡住不能继续执行操作）
//    
//    //3.1发送异步请求
//    //创建一个队列（默认添加到该队列中的任务异步执行）
//    //    NSOperationQueue *queue=[[NSOperationQueue alloc]init];
//    //获取一个主队列
//    NSOperationQueue *queue=[NSOperationQueue mainQueue];
//    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
//        
//        NSLog(@"response=  %@",request);
//         NSLog(@"--block回调数据--%@---%lu", [NSThread currentThread],(unsigned long)data.length);
//        NSLog(@"data ==== %@", [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]);
//        
//        
//    }];
  ////////////////////////////////////////////////////
    
   UIWebView * webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 44, 320, 440)];
    [webView setUserInteractionEnabled:YES];//是否支持交互
    //[webView setDelegate:self];
    webView.delegate=self;
    [webView setOpaque:NO];//opaque是不透明的意思
    [webView setScalesPageToFit:YES];//自动缩放以适应屏幕
    [self.view addSubview:webView];
    
    //加载网页的方式
    //1.创建并加载远程网页
    NSURL *url = [NSURL URLWithString:@"http://www.baidu.com"];
    [webView loadRequest:[NSURLRequest requestWithURL:url]];
    [self.view addSubview:webView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark --------获取相册的图片---------
- (void)getOriginalImages
{
    // 获得所有的自定义相簿
    PHFetchResult<PHAssetCollection *> *assetCollections = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
    // 遍历所有的自定义相簿
    for (PHAssetCollection *assetCollection in assetCollections) {
        [self enumerateAssetsInAssetCollection:assetCollection original:YES];
    }
    
    // 获得相机胶卷
    PHAssetCollection *cameraRoll = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil].lastObject;
    // 遍历相机胶卷,获取大图
    [self enumerateAssetsInAssetCollection:cameraRoll original:YES];
}
/**
 *  遍历相簿中的所有图片
 *  @param assetCollection 相簿
 *  @param original        是否要原图
 */
- (void)enumerateAssetsInAssetCollection:(PHAssetCollection *)assetCollection original:(BOOL)original
{
    NSLog(@"相簿名:%@", assetCollection.localizedTitle);
    
    PHImageRequestOptions *options = [[PHImageRequestOptions alloc] init];
    // 同步获得图片, 只会返回1张图片
    options.synchronous = YES;
    
    // 获得某个相簿中的所有PHAsset对象
    PHFetchResult<PHAsset *> *assets = [PHAsset fetchAssetsInAssetCollection:assetCollection options:nil];
    for (PHAsset *asset in assets) {
        
//        NSString * strurl=[[assetCollection
//                            defaultRepresentation]url]description];
        // 是否要原图
        CGSize size = original ? CGSizeMake(asset.pixelWidth, asset.pixelHeight) : CGSizeZero;
        
        // 从asset中获得图片
        [[PHImageManager defaultManager] requestImageForAsset:asset targetSize:size contentMode:PHImageContentModeDefault options:options resultHandler:^(UIImage * _Nullable result, NSDictionary * _Nullable info) {
//            NSLog(@"1-------- %@", [info objectForKey:@"PHImageFileURLKey"]);
            
            [imageArray addObject:[info objectForKey:@"PHImageFileURLKey"]];
            NSLog(@"1-------- %@", imageArray);
        }];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
//返回分区个数
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
//返回每个分区的item个数
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
//    return 10;
    return imageArray.count;
}
//返回每个item
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *collectionCellID = @"ACECollectionViewCell";
    ACECollectionViewCell *cell = (ACECollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:collectionCellID forIndexPath:indexPath];

//    [self originalImage:^(UIImage *image){
//        cell.photoImage.image=image;
//    }indexM:indexPath];
    const char* queueName = [[[NSDate date] description] UTF8String];
    dispatch_queue_t myQueue = dispatch_queue_create(queueName, NULL);
    dispatch_queue_t mainQueue = dispatch_get_main_queue();
    dispatch_async(myQueue, ^{
        //新线程中要操作的（例如数据库的读取，存储等）
             UIImage * imageNN=[UIImage imageWithData:[NSData dataWithContentsOfFile:imageArray[indexPath.row]]];
//        cell.photoImage.image=[UIImage imageWithData:[NSData dataWithContentsOfFile:imageArray[indexPath.row]]];
        dispatch_async(mainQueue, ^{
//            主线程中要操作的（例如UI页面刷新）
            cell.photoImage.image=imageNN;
        });
    });
//    cell.backgroundColor = [UIColor colorWithRed:arc4random()%255/255.0 green:arc4random()%255/255.0 blue:arc4random()%255/255.0 alpha:1];
    return cell;
}
- (void)originalImage:(void (^)(UIImage *))returnImage indexM:(NSIndexPath *)indexPath{
    ALAssetsLibrary *lib = [[ALAssetsLibrary alloc] init];
    [lib assetForURL:[NSURL URLWithString:imageArray[indexPath.row] ] resultBlock:^(ALAsset *asset) {
        ALAssetRepresentation *rep = asset.defaultRepresentation;
        CGImageRef imageRef = rep.fullResolutionImage;
        UIImage *image = [UIImage imageWithCGImage:imageRef scale:rep.scale orientation:(UIImageOrientation)rep.orientation];
        if (image) {
            returnImage(image);
        }
    } failureBlock:^(NSError *error) {
        
    }];
}

@end
