//
//  ACECollectionViewCell.m
//  GIF显示与制作
//
//  Created by admin on 16/9/5.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ACECollectionViewCell.h"
#import <AssetsLibrary/AssetsLibrary.h>
@implementation ACECollectionViewCell
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    
    
}


@end
