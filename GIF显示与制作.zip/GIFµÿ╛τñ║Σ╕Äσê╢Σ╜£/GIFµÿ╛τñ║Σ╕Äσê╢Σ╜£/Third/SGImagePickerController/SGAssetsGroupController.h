//
//  SGAssetsGroupController.h
//  SGImagePickerController
//
//  Created by yyx on 15/9/20.
//  Copyright (c) 2015年 yyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SGAssetsGroupController : UITableViewController
@property (nonatomic,assign) NSInteger maxCount;
@end
