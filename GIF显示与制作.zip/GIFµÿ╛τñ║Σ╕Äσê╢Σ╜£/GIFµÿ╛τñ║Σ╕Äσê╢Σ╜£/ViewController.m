//
//  ViewController.m
//  GIF显示与制作
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ViewController.h"
#import <ImageIO/ImageIO.h>
//#import <Accelerate/Accelerate.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "GifView.h"
#import "XCViewController.h"
@interface ViewController ()
{
    NSString * PathImage;
    
    GifView *dataView;   /////// gif显示View
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    PathImage=@"";
}


////// 点击屏幕  跳转相册
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
   XCViewController * avc=[[XCViewController alloc] init];
    [self presentViewController:avc animated:YES completion:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)tiaozhuanxiangce:(id)sender {
    XCViewController * avc=[[XCViewController alloc] init];
    [self presentViewController:avc animated:YES completion:nil];
    
    
}


- (IBAction)xianshi:(id)sender {
    
    if(!dataView){
        if(![PathImage isEqualToString:@""]){
        dataView = [[GifView alloc] initWithFrame:CGRectMake(50, 50, 100, 100) filePath:PathImage];
        }
        [[dataView layer] setBorderWidth:1.0];//画线的宽度
        [[dataView layer] setBorderColor:[UIColor blackColor].CGColor];//颜色
        [[dataView layer]setCornerRadius:15.0];//圆角
        dataView.backgroundColor=[UIColor clearColor];
        [self.view addSubview:dataView];
    }else
    {
        [dataView removeFromSuperview];
        dataView=nil;
    }
}

- (IBAction)zhizuoBut:(id)sender {
    
    NSMutableArray * imgs = [[NSMutableArray alloc]initWithCapacity:0];
    for (int i = 1; i < 29; i++) {
        [imgs addObject:[UIImage imageNamed:[NSString stringWithFormat:@"%d.png",i]]];
    }
    
    //创建输出路径
    NSArray *document = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentStr = [document objectAtIndex:0];
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *textDirectory = [documentStr stringByAppendingPathComponent:@"gif"];
    [fileManager createDirectoryAtPath:textDirectory withIntermediateDirectories:YES attributes:nil error:nil];
    NSString *path = [textDirectory stringByAppendingPathComponent:@"onewon.gif"];
    PathImage=path;
    [self gifhecheng:imgs :path];
}



-(void)gifhecheng:(NSMutableArray *)mArray :(NSString * )path
{
    
    //    1、创建图像目标
    
    CGImageDestinationRef destination;
    
    //    2、创建输出路径(保存的路径)
    /*
     path
     */
    //    3、创建CFURLRef对象
    
    CFURLRef url = CFURLCreateWithFileSystemPath(kCFAllocatorDefault, (CFStringRef)path, kCFURLPOSIXPathStyle, NO);
    
    //    4、通过一个url返回图像目标
    destination = CGImageDestinationCreateWithURL(url, kUTTypeGIF, mArray.count, nil);
    
    //    5、设置gif的信息，播放时隔事件，基本数据和delay事件
    NSDictionary *frameProperties = [NSDictionary dictionaryWithObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:0.18],(NSString *)kCGImagePropertyGIFDelayTime, nil] forKey:(NSString *)kCGImagePropertyGIFDictionary];
    
    //设置gif信息
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    [dict setObject:[NSNumber numberWithBool:YES] forKey:(NSString *)kCGImagePropertyGIFImageColorMap];
    
    [dict setObject:(NSString *)kCGImagePropertyColorModelRGB forKey:(NSString *)kCGImagePropertyColorModel];
    
    [dict setObject:[NSNumber numberWithInt:8] forKey:(NSString *)kCGImagePropertyDepth];
    
    [dict setObject:[NSNumber numberWithInt:0] forKey:(NSString *)kCGImagePropertyGIFLoopCount];
    
    NSDictionary *gifProperties = [NSDictionary dictionaryWithObject:dict forKey:(NSString *)kCGImagePropertyGIFDictionary];
    //    6、合成gif（把所有图片遍历添加到图像目标）
    for (UIImage *dImg in mArray)
    {
        CGImageDestinationAddImage(destination, dImg.CGImage, (__bridge CFDictionaryRef)frameProperties);
    }
    
    //    7、给gif添加信息
    CGImageDestinationSetProperties(destination, (__bridge CFDictionaryRef)gifProperties);
    
    //    8、写入gif图
    CGImageDestinationFinalize(destination);
    //    9、释放目标图像
    CFRelease(destination);
}



@end
