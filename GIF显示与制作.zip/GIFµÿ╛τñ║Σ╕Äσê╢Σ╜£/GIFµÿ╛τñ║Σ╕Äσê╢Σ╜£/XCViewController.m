//
//  XCViewController.m
//  GIF显示与制作
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "XCViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <ImageIO/ImageIO.h>
#import <Accelerate/Accelerate.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <AVFoundation/AVCaptureDevice.h>
#import <AVFoundation/AVMediaFormat.h>
#import "GifView.h"
#import "SGImagePickerController.h"

@interface XCViewController ()
{
    NSString *PathImage;
    GifView *dataView;   /////// gif显示View
    
   UIAlertView * customAlertView;//// 提示框
    float timeNJ;
    
    NSArray * iamgeArray;
    NSMutableArray * iamgeMUArray;
}
@end

@implementation XCViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    PathImage=@"";
    // Do any additional setup after loading the view from its nib.
    iamgeMUArray=[NSMutableArray arrayWithCapacity:0];
    
    if(dataView){
        self.view.backgroundColor=[UIColor blackColor];
    }
//    iamgeArray=[[NSArray array]init];
    
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    if (authStatus == AVAuthorizationStatusRestricted || authStatus ==AVAuthorizationStatusDenied)
    {
        //无权限
        NSLog(@"无权限");
    }else
    {
        NSLog(@"有权限");
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.view addSubview:_backBut];
    [self.view addSubview:_xcButton];
    if(dataView){
        self.view.backgroundColor=[UIColor blackColor];
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)backButton:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    exit(0);
}
- (IBAction)XCbutton:(id)sender {
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"制作提示"
                          
                                                    message:@"是否使用原图制作gif图？"
                          
                                                   delegate:self
                          
                                          cancelButtonTitle:@"NO"
                          
                                          otherButtonTitles:@"YES", nil];
    alert.tag=1002;
    
    [alert show];
    
//    [self xianshi];
  
    
  
}


-(void)xianshi
{

//    if(!dataView){
//        if(PathImage){
////        dataView = [[GifView alloc] initWithFrame:CGRectMake(1, 1, self.view.frame.size.width-2, self.view.frame.size.height-2) filePath:PathImage times:0.3];
//             NSData *reader = [NSData dataWithContentsOfFile:PathImage];
//            UIImage *image = [UIImage imageWithData: reader];
//            [self saveImageToPhotos:image];
//            dataView = [[GifView alloc] initWithFrame:CGRectMake(1, 1, self.view.frame.size.width-2, self.view.frame.size.height-2) data:reader times:0.4];
//            
//        }
////            NSLog(@"reader=  %@",reader);
//        [[dataView layer] setBorderWidth:1.0];//画线的宽度
//        [[dataView layer] setBorderColor:[UIColor blackColor].CGColor];//颜色
//        [[dataView layer]setCornerRadius:15.0];//圆角
//        dataView.backgroundColor=[UIColor clearColor];
//        dataView.layer.masksToBounds = YES;
//        dataView.layer.cornerRadius = 6.0;
//        dataView.layer.borderWidth = 1.0;
//        dataView.layer.borderColor = [[UIColor blackColor] CGColor];
//        [self.view addSubview:dataView];
//    }else
//    {
//        [dataView removeFromSuperview];
//        dataView=nil;
//    }
    NSData *reader = [NSData dataWithContentsOfFile:PathImage];
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(1, 1, self.view.frame.size.width-2, self.view.frame.size.height-2)];
    [self.view addSubview:webView];
    //自动调整尺寸
    webView.scalesPageToFit = YES;
    //禁止滚动
    webView.scrollView.scrollEnabled = NO;
    //设置透明效果
    webView.backgroundColor = [UIColor clearColor];
    webView.opaque = 0;
    //加载数据
    [webView loadData:reader MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];
    webView.contentMode = UIViewContentModeScaleAspectFill;
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    [library writeImageDataToSavedPhotosAlbum:reader metadata:nil completionBlock:^(NSURL *assetURL, NSError *error) {
        
        NSLog(@"Success at %@", [assetURL path] );
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"保存图片结果提示"
                              
                                                        message:[NSString stringWithFormat:@"%@",assetURL]
                              
                                                       delegate:self
                              
                                              cancelButtonTitle:@"确定"
                              
                                              otherButtonTitles:nil];
        customAlertView.tag=30001;
        
        [alert show];
    }] ;
}
//- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
//    SGImagePickerController *picker = [[SGImagePickerController alloc] init];
//    picker.maxCount = 4;
//    //返回选择的缩略图
//    [picker setDidFinishSelectThumbnails:^(NSArray *thumbnails) {
//        NSLog(@"缩略图%@",thumbnails);
//    }];
//    
//    //返回选中的原图
//    [picker setDidFinishSelectImages:^(NSArray *images) {
//        NSLog(@"原图%@",images);
//    }];
//    [self presentViewController:picker animated:YES completion:nil];
//}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag ==20001){
    if (buttonIndex == alertView.firstOtherButtonIndex) {
        UITextField *nameField = [alertView textFieldAtIndex:0];
       NSLog(@"%@",nameField.text);
        timeNJ=[nameField.text floatValue];
               //TODO
        
        NSArray *document = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentStr = [document objectAtIndex:0];
        NSFileManager *fileManager = [NSFileManager defaultManager];
        NSString *textDirectory = [documentStr stringByAppendingPathComponent:@"gif"];
        [fileManager createDirectoryAtPath:textDirectory withIntermediateDirectories:YES attributes:nil error:nil];
        NSString *path = [textDirectory stringByAppendingPathComponent:@"XC.gif"];
        PathImage=path;
//        [iamgeArray arrayByAddingObjectsFromArray:images];
        
        if (timeNJ) {
            int j=[self gifhecheng:iamgeArray :path timeS:timeNJ];
            if (j==1) {
                [self xianshi];
                [self.view addSubview:_backBut];
                [self.view addSubview:_xcButton];
//                if(dataView){
//                    self.view.backgroundColor=[UIColor blackColor];
//                }
            }
        }

    }
    
    }else if(alertView.tag == 1002)
    {
        if (buttonIndex == alertView.firstOtherButtonIndex) {
            
            
            
            if(dataView){
                [dataView removeFromSuperview];
                dataView=nil;
            }
            SGImagePickerController *picker = [[SGImagePickerController alloc] init];
            //返回选中的原图
            picker.maxCount = 4;
            [picker setDidFinishSelectImages:^(NSArray *images) {
                
//                NSLog(@"images= %lu",sizeof(images));
                for (int i=0; i<images.count; i++) {
//                   [iamgeMUArray addObject:[self addText:images[i] text:@"hello,word"]];
                    [iamgeMUArray addObject:[self watermarkImage:images[i] withName:@"大傻逼,你好"]];
                }
                
                iamgeArray=iamgeMUArray;
                //创建输出路径
                if (customAlertView==nil) {
                    customAlertView = [[UIAlertView alloc] initWithTitle:@"图片时间间隔" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                    customAlertView.tag=20001;
                }
                [customAlertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
                
                UITextField *nameField = [customAlertView textFieldAtIndex:0];
                nameField.placeholder = @"请输数值。";
                
                [customAlertView show];
                
            }];

            [self presentViewController:picker animated:YES completion:nil];
            
        }else
        {
        
            if(dataView){
                [dataView removeFromSuperview];
                dataView=nil;
            }
            SGImagePickerController *picker = [[SGImagePickerController alloc] init];
            picker.maxCount = 20;
            [picker setDidFinishSelectThumbnails:^(NSArray *thumbnails) {
                NSLog(@"images= %lu",sizeof(thumbnails));
                iamgeArray=thumbnails;
                //创建输出路径
                if (customAlertView==nil) {
                    customAlertView = [[UIAlertView alloc] initWithTitle:@"图片时间间隔" message:nil delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
                    customAlertView.tag=20001;
                }
                [customAlertView setAlertViewStyle:UIAlertViewStylePlainTextInput];
                
                UITextField *nameField = [customAlertView textFieldAtIndex:0];
                nameField.placeholder = @"请输数值。";
                
                [customAlertView show];
            }];
            
            
            
            [self presentViewController:picker animated:YES completion:nil];
        }
    
    }
    
}

//1.加文字

-(UIImage *)addText:(UIImage *)img text:(NSString *)text1
{
    //get image width and height
    int w = img.size.width;
    int h = img.size.height;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    //create a graphic context with CGBitmapContextCreate
    CGContextRef context = CGBitmapContextCreate(NULL, w, h, 8, 4 * w, colorSpace, kCGImageAlphaPremultipliedFirst);
    CGContextDrawImage(context, CGRectMake(0, 0, w, h), img.CGImage);
    CGContextSetRGBFillColor(context, 0.0, 1.0, 1.0, 1);
    char* text = (char *)[text1 cStringUsingEncoding:NSASCIIStringEncoding];
    CGContextSelectFont(context, "Georgia", 30, kCGEncodingMacRoman);
    CGContextSetTextDrawingMode(context, kCGTextFill);
    CGContextSetRGBFillColor(context, 255, 0, 0, 1);
    CGContextShowTextAtPoint(context, w/2-strlen(text)*5, h/2, text, strlen(text));
    //Create image ref from the context
    CGImageRef imageMasked = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    return [UIImage imageWithCGImage:imageMasked];
}

//2.加图片
-(UIImage *)addImageLogo:(UIImage *)img text:(UIImage *)logo
{
    //get image width and height
    int w = img.size.width;
    int h = img.size.height;
    int logoWidth = logo.size.width;
    int logoHeight = logo.size.height;
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    //create a graphic context with CGBitmapContextCreate
    CGContextRef context = CGBitmapContextCreate(NULL, w, h, 8, 4 * w, colorSpace, kCGImageAlphaPremultipliedFirst);
    CGContextDrawImage(context, CGRectMake(0, 0, w, h), img.CGImage);
    CGContextDrawImage(context, CGRectMake(w-logoWidth, 0, logoWidth, logoHeight), [logo CGImage]);
    CGImageRef imageMasked = CGBitmapContextCreateImage(context);
    CGContextRelease(context);
    CGColorSpaceRelease(colorSpace);
    return [UIImage imageWithCGImage:imageMasked];
    //  CGContextDrawImage(contextRef, CGRectMake(100, 50, 200, 80), [smallImg CGImage]);
}
// 画水印
//3.加半透明的水印
- (UIImage *)addImage:(UIImage *)useImage addImage1:(UIImage *)addImage1
{
    UIGraphicsBeginImageContext(useImage.size);
    [useImage drawInRect:CGRectMake(0, 0, useImage.size.width, useImage.size.height)];
    [addImage1 drawInRect:CGRectMake(0, useImage.size.height-addImage1.size.height, addImage1.size.width, addImage1.size.height)];
    UIImage *resultingImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return resultingImage;
}

 /////////  加文字
-(UIImage *)watermarkImage:(UIImage *)img withName:(NSString *)name

 {
    
         NSString* mark = name;
    
         int w = img.size.width;
    
         int h = img.size.height;
    
         UIGraphicsBeginImageContext(img.size);
    
         [img drawInRect:CGRectMake(0, 0, w, h)];
    
         NSDictionary *attr = @{
                                
                                                              NSFontAttributeName: [UIFont boldSystemFontOfSize:28],   //设置字体
                                  
                                                              NSForegroundColorAttributeName : [UIColor whiteColor]      //设置字体颜色
                                  
                                                              };
    
         [mark drawInRect:CGRectMake(0, 10, 150, 40) withAttributes:attr];                 //左上角
    
         [mark drawInRect:CGRectMake(w - 80, 10, 150, 40) withAttributes:attr];            //右上角
//
         [mark drawInRect:CGRectMake(w - 80, h - 32 - 10, 150, 40) withAttributes:attr];   //右下角
     NSLog(@"w= %d",w);
//     [mark drawInRect:CGRectMake(w/2+20, h - 42 - 10, 100, 42) withAttributes:attr];   //最下面中间
//
         [mark drawInRect:CGRectMake(0, h - 32 - 10, 150, 40) withAttributes:attr];        //左下角
 
     UIImage *aimg = UIGraphicsGetImageFromCurrentImageContext();
 
     UIGraphicsEndImageContext();
     return aimg;

 }

-(int)gifhecheng:(NSArray *)mArray :(NSString * )path timeS:(float) time
{
    
    //    1、创建图像目标
    
    CGImageDestinationRef destination;
    
    //    2、创建输出路径(保存的路径)
    /*
     path
     */
    //    3、创建CFURLRef对象
    
    CFURLRef url = CFURLCreateWithFileSystemPath(kCFAllocatorDefault, (CFStringRef)path, kCFURLPOSIXPathStyle, NO);
    
    //    4、通过一个url返回图像目标
    destination = CGImageDestinationCreateWithURL(url, kUTTypeGIF, mArray.count, nil);
    NSDictionary *frameProperties;
    //    5、设置gif的信息，播放时隔事件，基本数据和delay事件
//    NSDictionary *frameProperties = [NSDictionary dictionaryWithObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:0.38],(NSString *)kCGImagePropertyGIFDelayTime, nil] forKey:(NSString *)kCGImagePropertyGIFDictionary];
    if (time) {
    frameProperties = [NSDictionary dictionaryWithObject:[NSMutableDictionary dictionaryWithObjectsAndKeys:[NSNumber numberWithFloat:time],(NSString *)kCGImagePropertyGIFDelayTime, nil] forKey:(NSString *)kCGImagePropertyGIFDictionary];
    }
    
    
    //设置gif信息
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithCapacity:2];
    
    [dict setObject:[NSNumber numberWithBool:YES] forKey:(NSString *)kCGImagePropertyGIFImageColorMap];
    
    [dict setObject:(NSString *)kCGImagePropertyColorModelRGB forKey:(NSString *)kCGImagePropertyColorModel];
    
    [dict setObject:[NSNumber numberWithInt:8] forKey:(NSString *)kCGImagePropertyDepth];
    
    [dict setObject:[NSNumber numberWithInt:0] forKey:(NSString *)kCGImagePropertyGIFLoopCount];
    
    NSDictionary *gifProperties = [NSDictionary dictionaryWithObject:dict forKey:(NSString *)kCGImagePropertyGIFDictionary];
    //    6、合成gif（把所有图片遍历添加到图像目标）
    for (UIImage *dImg in mArray)
    {
        CGImageDestinationAddImage(destination, dImg.CGImage, (__bridge CFDictionaryRef)frameProperties);
    }
    
    //    7、给gif添加信息
    CGImageDestinationSetProperties(destination, (__bridge CFDictionaryRef)gifProperties);
    
    //    8、写入gif图
    CGImageDestinationFinalize(destination);
    //    9、释放目标图像
    CFRelease(destination);
    return 1;
}


- (void)saveImageToPhotos:(UIImage*)savedImage
{
  
    UIImageWriteToSavedPhotosAlbum(savedImage, self, @selector(image:didFinishSavingWithError:contextInfo:), NULL);
   
}

// 指定回调方法

- (void)image: (UIImage *) image didFinishSavingWithError: (NSError *) error contextInfo: (void *) contextInfo

{
    
    NSString *msg = nil ;

    if(error != NULL){
       
        msg = @"保存图片失败" ;
        
    }else{
       
        msg = @"保存图片成功" ;
   
    }
  
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"保存图片结果提示"
                     
                                                    message:msg
                    
                                                   delegate:self
                         
                                          cancelButtonTitle:@"确定"
                         
                                          otherButtonTitles:nil];
    
    [alert show];
    
}

@end
