//
//  XCViewController.h
//  GIF显示与制作
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 admin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XCViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIButton *backBut;

@property (weak, nonatomic) IBOutlet UIButton *xcButton;

-(int)gifhecheng:(NSArray *)mArray :(NSString * )path timeS:(float) time;
@end
