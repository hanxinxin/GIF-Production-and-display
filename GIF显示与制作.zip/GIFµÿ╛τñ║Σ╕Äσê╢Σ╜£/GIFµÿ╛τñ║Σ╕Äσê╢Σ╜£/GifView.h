//
//  GifView.h
//  NOW
//
//  Created by admin on 16/8/30.
//  Copyright © 2016年 ArJun. All rights reserved.
//

/**
 *  调用结束就开始播放动画，如果需要用户指定何时播放的话，只需要把timer的开始放到合适的位置。通过对CFDictonaryRaf 也就是gifPRoperties的改变，我们还可以控制动画是否循环播放以及循环多少次停止。
 
 通过对index的改变也可以控制动画从某帧开始播放。同理，同时改变index和count的话，也可以控制从某帧到某帧的播放。
 注意：- (void)stopGif;之后才可以退出这个类。否则timer不会关闭，产生内存泄露。
 */

#import <UIKit/UIKit.h>
#import <ImageIO/ImageIO.h>

@interface GifView : UIView {
    CGImageSourceRef gif; // 保存gif动画
    NSDictionary *gifProperties;  // 保存gif动画属性
    size_t index;// gif动画播放开始的帧序号
    size_t count;// gif动画的总帧数
    NSTimer *timer;// 播放gif动画所使用的timer
}
- (id)initWithFrame:(CGRect)frame filePath:(NSString *)_filePath times:(NSTimeInterval)time;
- (id)initWithFrame:(CGRect)frame filePath:(NSString *)_filePath;
- (id)initWithFrame:(CGRect)frame data:(NSData *)_data times:(NSTimeInterval)time;
- (id)initWithFrame:(CGRect)frame data:(NSData *)_data;
- (void)stopGif;
//加载Gif的三种方式：（从网络或者本地）
//
//- (NSData *)loadDataForIndex:(NSInteger)index {
//    NSData *data = nil;
//    if (index == 0) {
//        //网络
//        data = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://s14.sinaimg.cn/mw690/005APVsyzy6MFOsVFfv5d&690"]];
//    }else {
//        //本地
//        data = [NSData dataWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"run" ofType:@"gif"]];
//    }
//    return data;
//}
//1.GifView
//
////第三方GifView(实现gif动画播放是通过将动画文件读取到CGImageSourceRef，然后用NSTimer来播放的。)
//
////- (id)initWithFrame:(CGRect)frame filePath:(NSString *)_filePath;
//GifView *dataView = [[GifView alloc] initWithFrame:CGRectMake(0, 0, 100, 100) data:data];
//[self.view addSubview:dataView];
////    [dataView stopGif];
//2.webView(不会出现内存问题)
//
////webView
//UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 120, 100, 100)];
//webView.backgroundColor = [UIColor redColor];
//webView.scalesPageToFit = YES;
//[webView loadData:data MIMEType:@"image/gif" textEncodingName:nil baseURL:nil];
//[self.view addSubview:webView];
//3.帧动画
//
//- (void)runGIFForImage {
//    UIImageView *gifImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 240, 100, 100)];
//    NSArray *gifArray = [NSArray arrayWithObjects:[UIImage imageNamed:@"1"],
//                         [UIImage imageNamed:@"2"],
//                         [UIImage imageNamed:@"3"],
//                         [UIImage imageNamed:@"4"],
//                         [UIImage imageNamed:@"5"],
//                         [UIImage imageNamed:@"6"],
//                         [UIImage imageNamed:@"7"],
//                         [UIImage imageNamed:@"8"],
//                         [UIImage imageNamed:@"9"],
//                         [UIImage imageNamed:@"10"],
//                         [UIImage imageNamed:@"11"],
//                         [UIImage imageNamed:@"12"],
//                         [UIImage imageNamed:@"13"],
//                         [UIImage imageNamed:@"14"],
//                         [UIImage imageNamed:@"15"],
//                         [UIImage imageNamed:@"16"],
//                         [UIImage imageNamed:@"17"],
//                         [UIImage imageNamed:@"18"],
//                         [UIImage imageNamed:@"19"],
//                         [UIImage imageNamed:@"20"],
//                         [UIImage imageNamed:@"21"],
//                         [UIImage imageNamed:@"22"],nil];
//    gifImageView.animationImages = gifArray; //动画图片数组
//    gifImageView.animationDuration = 5; //执行一次完整动画所需的时长
//    gifImageView.animationRepeatCount = 999;  //动画重复次数
//    [gifImageView startAnimating];
//    [self.view addSubview:gifImageView];
//}
@end
